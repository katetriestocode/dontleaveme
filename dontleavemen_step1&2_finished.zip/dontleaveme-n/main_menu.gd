extends Node2D

# Files
@onready var readme: TextureButton = %readme
@onready var file_explorer: TextureButton = %"File explorer"
@onready var top_secret: TextureButton = %"TOP SECRET"
@onready var gmail: TextureButton = %Gmail

#Riddle 1 variables
@onready var Riddle1: TextureRect = %Riddle1
@onready var riddle_1_close: TextureButton = %riddle_1_close
@onready var password_input: LineEdit = %password_input
@onready var label: Label = %label

# Access
@onready var access_granted: CanvasItem = %"access granted"
@onready var access_denied: CanvasItem = %"access denied"
@onready var close_x: Button = %close_x
@onready var close_ok: Button = %close_ok


# Community variables
var password1: String = "chooseme"
var riddle1done: bool = false


func _ready() -> void:
	Riddle1.visible = false
	password_input.editable = false
	password_input.visible = false
	access_granted.visible = false
	access_denied.visible = false
	
	
	close_x.disabled = true
	close_ok.disabled = true

	
	password_input.text_submitted.connect(_on_password_input_text_entered)
	readme.pressed.connect(_on_readme_pressed)
	
	file_explorer.pressed.connect(_on_file_explorer_pressed)
	top_secret.pressed.connect(_on_top_secret_pressed)
	gmail.pressed.connect(_on_gmail_pressed)
	

	close_x.pressed.connect(_on_close_x_pressed)
	close_ok.pressed.connect(_on_close_ok_pressed)
		
	if riddle_1_close:
		riddle_1_close.pressed.connect(_on_riddle_1_close_pressed)
		
	
	
func _on_readme_pressed() -> void:
	Riddle1.visible = true
	password_input.editable = true
	password_input.visible = true
	password_input.grab_focus()
	


func _on_riddle_1_close_pressed() -> void:
	Riddle1.visible = false
	password_input.editable = false

	password_input.text = ""
	password_input.release_focus()
	
	access_granted.visible = false
	access_denied.visible = false
	


func _on_password_input_text_entered(new_text: String) -> void:
	close_x.disabled = false
	close_ok.disabled = false
	if new_text.strip_edges().to_lower() == password1:
		riddle1done = true
		access_granted.visible = true
		access_denied.visible = false
	else:
		access_denied.visible = true
		access_granted.visible = false
		password_input.text = ""
		password_input.grab_focus()
		
		
func _on_file_explorer_pressed() -> void:
	if not riddle1done:
		file_explorer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	else: 
		file_explorer.mouse_filter = Control.MOUSE_FILTER_STOP


func _on_top_secret_pressed() -> void:
	# TODO: gate this behind the Morse code answer once that puzzle is built
	pass


func _on_gmail_pressed() -> void:
	# TODO: gate this behind the Mail password once that puzzle is built
	pass

			

func _on_close_x_pressed() -> void:
	access_granted.visible = false
	access_denied.visible = false
	if riddle1done:
		_on_riddle_1_close_pressed()


func _on_close_ok_pressed() -> void:
	access_granted.visible = false
	access_denied.visible = false
	if riddle1done:
		_on_riddle_1_close_pressed()
