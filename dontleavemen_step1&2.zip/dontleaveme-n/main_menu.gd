extends Node2D

# Riddle 1 buttons
@onready var readme: TextureButton = %readme
@onready var Riddle1: TextureRect = %Riddle1
@onready var riddle_1_close: TextureButton = %riddle_1_close
@onready var password_input: LineEdit = %password_input
@onready var label: Label = %label


func _ready() -> void:
	Riddle1.visible = false
	password_input.editable = false
	password_input.visible = false
	
	password_input.text_submitted.connect(_on_password_input_text_entered)
	readme.pressed.connect(_on_readme_pressed)
	
	if riddle_1_close:
		riddle_1_close.pressed.connect(_on_riddle_1_close_pressed)
	
	
func _on_readme_pressed() -> void:
	Riddle1.visible = true
	password_input.editable = true
	password_input.visible = true
	password_input.grab_focus()
	
func _on_riddle_1_close_pressed() -> void:
	Riddle1.visible = false
	password_input.editable = false

	password_input.text = ""
	password_input.release_focus()
	
func _on_password_input_text_entered(new_text: String) -> void:
	if new_text.strip_edges().to_lower() == "choose me":
		label.text = "access granted"
	else: 
		label.text = "access granted"
		
		
