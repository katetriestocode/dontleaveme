
extends Node2D

func _ready() -> void:
	$cheese.hide()
	$diary.hide()
	$numbers.hide()

func _process(delta: float) -> void:
	pass

func _on_my_fav_cheese_pressed() -> void:
	$cheese.show()


func _on_uncs_diary_pressed() -> void:
	$diary.show()
	
	#if theres time make it dragable
	# change it to the actual scene once you get the grapic


func _on_i_3_numbers_pressed() -> void:
	$numbers.show()
	# change it to the actual scene once you get the grapic


func _on_x_step_3_pressed() -> void:
	hide()



func _on_full_screen_pressed() -> void:
	#fix it bc it's not going full scren and make sure tha scale reajust is self along side the sceen to the buutons wont magicly disapear
	if DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_FULLSCREEN:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)


func _on_x_diary_pressed() -> void:
	$diary.hide() 
	



func _on_x_cheese_pressed() -> void:
	$cheese.hide()
	





func _on_x_numbers_pressed() -> void:
	$numbers.hide()
