extends Node2D

# --- Riddle 1 (readme cipher) ---
@onready var readme: TextureButton = %readme
@onready var Riddle1: TextureRect = %Riddle1
@onready var riddle_1_close: TextureButton = %riddle_1_close
@onready var password_input: LineEdit = %password_input
@onready var label: Label = %label

# --- Access feedback graphics ---
# Quoted %"Node Name" is required for unique names that contain spaces.
@onready var access_granted: CanvasItem = %"access granted"
@onready var access_denied: CanvasItem = %"access denied"

# --- Other desktop icons ---
@onready var file_explorer: TextureButton = %"File explorer"
@onready var top_secret: TextureButton = %"TOP SECRET"
@onready var gmail: TextureButton = %Gmail

# --- Puzzle state ---
# Simple bools for now since everything lives in one scene/script.
var riddle_1_solved: bool = false

func _ready() -> void:
	Riddle1.visible = false
	password_input.editable = false
	password_input.visible = false
	access_granted.visible = false
	access_denied.visible = false

	password_input.text_submitted.connect(_on_password_input_text_entered)
	readme.pressed.connect(_on_readme_pressed)

	if riddle_1_close:
		riddle_1_close.pressed.connect(_on_riddle_1_close_pressed)

	file_explorer.pressed.connect(_on_file_explorer_pressed)
	top_secret.pressed.connect(_on_top_secret_pressed)
	gmail.pressed.connect(_on_gmail_pressed)


func _on_readme_pressed() -> void:
	Riddle1.visible = true
	password_input.editable = true
	password_input.visible = true
	password_input.grab_focus()


func _on_riddle_1_close_pressed() -> void:
	Riddle1.visible = false
	password_input.editable = false
	password_input.text = ""
	password_input.release_focus()
	access_granted.visible = false
	access_denied.visible = false


func _on_password_input_text_entered(new_text: String) -> void:
	if new_text.strip_edges().to_lower() == "chooseme":
		riddle_1_solved = true
		label.text = "access granted"
		access_granted.visible = true
		access_denied.visible = false
	else:
		label.text = "access denied"
		access_denied.visible = true
		access_granted.visible = false
		password_input.text = ""
		password_input.grab_focus()


func _on_file_explorer_pressed() -> void:
	if not riddle_1_solved:
		return  # locked -- riddle 1 hasn't been solved yet
	# TODO: show the File Explorer window once that scene/UI exists
	print("File explorer unlocked")


func _on_top_secret_pressed() -> void:
	# TODO: gate this behind the Morse code answer once that puzzle is built
	pass


func _on_gmail_pressed() -> void:
	# TODO: gate this behind the Mail password once that puzzle is built
	pass
