extends Node

#import the real var from nomeda zip
var mail_visible: bool = true
const EMAILJS_URL: String = "https://api.emailjs.com/api/v1.0/email/send"
const SERVICE_ID: String = "gmail2"
const TEMPLATE_ID: String = "template_tr85ng6"
const PUBLIC_KEY: String = "ltHoWSgXrKnyLqlsh"
const PRIVATE_KEY: String = "w9wa7RmqfmbXSB4moRKdJ"

# 1. REQUIRED: Create the web request tool in computer memory
var http_request: HTTPRequest = HTTPRequest.new()

func _ready() -> void:
	# 2. REQUIRED: Godot forces internet tools to be attached to the scene tree before they can work
	add_child(http_request)
	http_request.request_completed.connect(func(res, code, hdrs, body): print("SERVER REPLY: ", code, " | ", body.get_string_from_utf8()))
	$mail_graphic/sent.hide()
	$mail_graphic/hint.hide()
	if mail_visible == false:
		$mail_graphic.hide()
	else:
		$mail_graphic.show()

func _on_send_pressed() -> void:
	if $mail_graphic/subject.text == "morse":
		# 3. REQUIRED: Actually read the text box to see what email address the user typed
		var player_email: String = $mail_graphic/user_email.text
		
		# 4. DIRECT EXECUTION: No extra functions. We just pack the data and fire the request!
		var headers: PackedStringArray = ["Content-Type: application/json"]
		var body: Dictionary = {
			"service_id": SERVICE_ID,
			"template_id": TEMPLATE_ID,
			"user_id": PUBLIC_KEY,
			"accessToken": PRIVATE_KEY, # REQUIRED: Sends the private key to authenticate the request
			"template_params": {"to_email": player_email}
		}
		var json_body: String = JSON.stringify(body)
		http_request.request(EMAILJS_URL, headers, HTTPClient.METHOD_POST, json_body)
		
		$mail_graphic/sent.show()
		await get_tree().create_timer(1.0).timeout
		$mail_graphic/sent.hide()
	else:
		$mail_graphic/hint.show()
		await get_tree().create_timer(0.5).timeout
		$mail_graphic/hint.hide()
		
func _on_x_mail_pressed() -> void:
	# 5. REQUIRED: Change to simply hide() so Godot doesn't search for a non-existent child node
	$mail_graphic.hide()
	mail_visible = false
